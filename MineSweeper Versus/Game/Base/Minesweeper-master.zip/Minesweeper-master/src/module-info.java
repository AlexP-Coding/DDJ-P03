module minesweeper {
	requires javafx.controls;
	requires static org.junit.jupiter.api;
	requires transitive javafx.graphics;	
	exports ca.mcgill.cs.swevo.minesweeper;
}