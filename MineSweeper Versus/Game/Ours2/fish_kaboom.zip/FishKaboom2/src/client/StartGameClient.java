package client;

import java.io.IOException;

public class StartGameClient {
	
	public static void main(String[] args) throws IOException {
		WelcomeWindow window = new WelcomeWindow();
	}
}
