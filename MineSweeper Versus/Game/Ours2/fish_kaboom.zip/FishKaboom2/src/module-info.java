/**
 * 
 */
/**
 * @author jenis
 *
 */
module FishKaboom2 {
	requires java.desktop;
}